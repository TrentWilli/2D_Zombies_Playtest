To play playtest version
1. Download .zip
2. Unzip to a folder
3. CLick 'Top-Down Zombie Survival' with the unity icon next to it
